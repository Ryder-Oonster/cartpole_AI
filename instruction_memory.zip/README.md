# cartpole_AI
 Training an AI to play cartpole in PyGame
